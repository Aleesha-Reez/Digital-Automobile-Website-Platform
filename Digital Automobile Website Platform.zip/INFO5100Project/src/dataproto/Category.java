package dataproto;

enum Category {
    NEW, USED;
}
