//package dataproto;
//
//enum VehicleCategory
//{
//  //todo
//}
