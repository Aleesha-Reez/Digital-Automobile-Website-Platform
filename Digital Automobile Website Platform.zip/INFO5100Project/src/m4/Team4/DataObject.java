package m4.Team4;


public class DataObject {
	protected String id;
}
