package m4.Team1.database.utils;

public class Constants {
	public static final String sqlUrl = "jdbc:sqlserver://is-swang01.ischool.uw.edu:1433;databaseName=VechileManagementSystem;user=INFO6210;password=NEUHusky!";
	public static final String carTableName = "CarInventory";
	public static final String customerRequestTableName = "CustomerRequest";
}
